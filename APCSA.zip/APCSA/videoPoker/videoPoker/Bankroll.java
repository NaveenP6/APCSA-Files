public class Bankroll
{
    private int bankroll;
    public Bankroll(int a)
    {
        bankroll = a;
    }
    public int getBankroll()
    {
        return bankroll;
    }
    public void changeBankroll(int a)
    {
        bankroll += a;
    }
}