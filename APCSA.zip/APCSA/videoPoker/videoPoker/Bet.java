public class Bet
{
    private int bet;
    public Bet()
    {
        bet = 0;
    }
    public int getBet()
    {
        return bet;
    }
    public void setBet(int a)
    {
        bet = a;
    }
}