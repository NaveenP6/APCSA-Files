public class Card
{
    private int val;
    private int suit;
    
    String[] values = {"Ace", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Jack", "Queen", "King"};
    String[] suits = {"Clubs", "Diamonds", "Hearts", "Spades"};
    
    public Card(int v, int s)
    {
        val = v;
        suit = s;
    }
    
    public int getValue()
    {
        return val;
    }
    
    public int getSuit()
    {
        return suit;
    }
    
    public String getName()
    {
       return values[val-1] + " of " + suits[suit-1];
    }
}

