/*
 * It's up to you to figure out how to use Player with the rest of your code
 * Do not change
 */

import java.util.Scanner;
import java.util.ArrayList;

public class Player
{
  private Bet bet;
  private Bankroll bank;
  private Scanner input;
  
  public Player()
  {
    input = new Scanner(System.in);
    bet = new Bet();
    System.out.println("Enter starting bankroll");
    bank = new Bankroll(input.nextInt());
  }
  
  public int addToBankroll()
  {
    int amount = 0;
    do
    {
      System.out.println("How many credits would you like to add to your bankroll?");
      amount = input.nextInt();
    } while(amount < 0);
    return amount;
  }
  
  public void updateBankroll(int amount)
  {
    bank.changeBankroll(amount);
  }
  
  public void getPlayerBet()
  {
    int currentBet = 0;
    do
    {
      System.out.println("How many credits would you like to bet?\n(1 - " + bank.getBankroll() + ")");
      currentBet = input.nextInt();
    } while(currentBet <= 0 || currentBet > bank.getBankroll());
    bet.setBet(currentBet);
  }
  
  public void showHand(String[] hand)
  {
    for(int i = 0; i < hand.length - 1; i++)
      System.out.print(hand[i] + ", ");
    System.out.println(hand[4]);
  }
  
  public int[] getDiscards()
  {
    ArrayList<Integer> dis = new ArrayList<Integer>();
    for(int i = 1; i <= 5; i++)
    {
      System.out.println("Do you want to discard card " + i + "\n(1 = Yes, 0 = No)");
      if(input.nextInt() == 1)
        dis.add(i);
    }
    
    int[] discards = new int[dis.size()];
    
    for(int i = 0; i < discards.length; i++)
      discards[i] = dis.get(i);
    return discards;
  }
  
  public int displayResults(int score)
  {
    if(score == 250)
      System.out.println("Royal Flush!");
    if(score == 50)
      System.out.println("Straight Flush!");
    if(score == 25)
      System.out.println("Four of a Kind!");
    if(score == 9)
      System.out.println("Full House!");
    if(score == 6)
      System.out.println("Flush!");
    if(score == 4)
      System.out.println("Straight!");
    if(score == 3)
      System.out.println("Three of a Kind!");
    if(score == 2)
      System.out.println("Two Pair!");
    if(score == 1)
      System.out.println("Pair!");
    if(score == -1)
      System.out.println("Losing Hand :-(");
    
    if(score == -1)
      System.out.println("You lost " + bet.getBet() + " credits");
    else
      System.out.println("You won " + bet.getBet() * score + " credits");
      
    return bet.getBet();
  }
  
  public void quit()
  {
    System.out.println("Game Over");
    if(bank.getBankroll() == 0)
      System.out.println("You're broke, better luck next time");
    else
      System.out.println("You're walking away with " + bank.getBankroll() + " credits");
  }
  
  public int menu()
  {
    if(bank.getBankroll() == 0)
      return 3;
    int choice = 0;
    do
    {
      System.out.println("Make a choice\n\t1. Make a bet and play\n\t2. Add credits\n\t3. Cash out and quit");
      choice = input.nextInt();
    } while (choice < 1 || choice > 3);
    return choice;
  }
}