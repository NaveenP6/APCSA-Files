public class Hand
{
    private Deck gameDeck;
    private Card[] hand;
    public Hand()
    {
        gameDeck = new Deck();
        hand = new Card[5];
    }
    
    
    public void newHand()
    {
        gameDeck.shuffle();
        
        for(int i = 0; i < hand.length; i++)
        {
            hand[i] = gameDeck.deal();
        }
        
    }
    
    public String[] getHand()
    {
        String[] playerHand = new String[5];
        
        for(int i = 0; i < 5; i++)
        {
            playerHand[i] = hand[i].getName();
        }
        
        return playerHand;
    }
    
    public void discard(int num)
    {
        hand[num-1] = gameDeck.deal(); 
    }
    
    public int scoreHand()
    {
        int score = 0;
        for(int i = 0; i < hand.length; i++)
        {
            int minIndex = i;
            for(int j = i+1; j < hand.length; j++)
            {
                if(hand[j].getValue() < hand[minIndex].getValue())
                {
                    minIndex = j;
                }
            }
            
            Card temp = hand[i];
            hand[i] = hand[minIndex];
            hand[minIndex] = temp;
        }
        
        
        if(hand[0].getValue() == 1 && hand[1].getValue() == 10 && hand[2].getValue() == 11 && hand[3].getValue() == 12 && hand[4].getValue() == 13 && hand[1].getSuit() == hand[0].getSuit() && hand[2].getSuit() 
            == hand[0].getSuit() && hand[3].getSuit() == hand[0].getSuit() && hand[4].getSuit() == hand[0].getSuit())
        {
            // Royal Flush
            score = 250;
        } 
        else if(hand[1].getValue() == (hand[0].getValue() +1) && hand[2].getValue() == (hand[1].getValue() +1) && hand[3].getValue() == (hand[2].getValue() +1) && hand[4].getValue() 
                == (hand[3].getValue() +1) && hand[1].getSuit() == hand[0].getSuit() && hand[2].getSuit() == hand[0].getSuit() && hand[3].getSuit() == hand[0].getSuit() && hand[4].getSuit() == hand[0].getSuit())
        {
            // Straight Flush
            score = 50;
        }
        else if((hand[0].getValue() == hand[1].getValue() && hand[0].getValue() == hand[2].getValue() && hand[0].getValue() == hand[3].getValue()) || (hand[1].getValue() 
                == hand[2].getValue() && hand[1].getValue() == hand[3].getValue() && hand[1].getValue() == hand[4].getValue()))
        {
            // Four of a Kind
            score = 25;
        }
        else if((hand[0].getValue() == hand[1].getValue() && hand[0].getValue() == hand[2].getValue() && hand[3].getValue() == hand[4].getValue()) || (hand[0].getValue() 
                == hand[1].getValue() && hand[2].getValue() == hand[3].getValue() && hand[2].getValue() == hand[4].getValue()))
        {
            // Full House
            score = 9;
        }
        else if(hand[1].getSuit() == hand[0].getSuit() && hand[2].getSuit() == hand[0].getSuit() && hand[3].getSuit() == hand[0].getSuit() && hand[4].getSuit() == hand[0].getSuit())
        {
            //Flush
            score = 6;
        }
        else if((hand[1].getValue() == (hand[0].getValue() +1) && hand[2].getValue() == (hand[1].getValue() +1) && hand[3].getValue() == (hand[2].getValue() +1) && hand[4].getValue() 
                == (hand[3].getValue() +1)) || (hand[0].getValue() == 1 && hand[1].getValue() == 10 && hand[2].getValue() == 11 && hand[3].getValue() == 12 && hand[4].getValue() == 13))
        {
            //Straight
            score = 4;
        }
        else if((hand[0].getValue() == hand[1].getValue() && hand[0].getValue() == hand[2].getValue()) || (hand[1].getValue() == hand[2].getValue() && hand[1].getValue() 
                == hand[3].getValue()) || (hand[2].getValue() == hand[3].getValue() && hand[2].getValue() == hand[4].getValue()))
        {
            // Three of a Kind
            score = 3;
        }
        else if((hand[0].getValue() == hand[1].getValue() && (hand[2].getValue() == hand[3].getValue() || hand[3].getValue() == hand[4].getValue())) || 
                (hand[1].getValue() == hand[2].getValue() && hand[3].getValue() == hand[4].getValue()))
        {
            // Two Pair
            score = 2;
        }
        else if((hand[0].getValue() == hand[1].getValue()) || (hand[1].getValue() == hand[2].getValue()) || (hand[2].getValue() == hand[3].getValue()) || (hand[3].getValue() == hand[4].getValue()))
        {
            // Pair
            score = 1;
        }
        else
        {
            score = -1;
        }
        
        return score;
    }
}