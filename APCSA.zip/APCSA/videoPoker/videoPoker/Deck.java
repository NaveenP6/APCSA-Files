import java.util.ArrayList;
public class Deck
{
    private ArrayList<Card> cardList = new ArrayList<Card>();
    private ArrayList<Card> dealtCardList = new ArrayList<Card>();
    
    public Deck()
    {
        for (int i = 1; i <= 4; i++)
        {
            for (int j = 1; j <= 13; j++)
            {
                cardList.add(new Card(j,i));
            }
        }
        //CALL SHUFFLE
        shuffle();
    }
    
    public Card deal()
    {
        //mix up in shuffle NOT deal; in deal return remove the first one!!!
        dealtCardList.add(0, cardList.remove(0));
        return dealtCardList.get(0);
    }
    
    public void shuffle()
    {
       for(int i = dealtCardList.size()-1; i >= 0; i--)
       {
          cardList.add(dealtCardList.remove(i));
       }
       
       for(int i = 52; i >= 0; i--)
       {
           cardList.add(cardList.remove((int)(Math.random() * i)));
       }
    }
}
