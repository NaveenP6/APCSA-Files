public class Game
{
    private static Player user;
    private static Hand userHand;
    public Game()
    {
        user = new Player();
        userHand = new Hand();
    }
    
    public static void main(String[] args) 
    {
        Game newRound = new Game();
        newRound.play();
    }   
    
    public static void play()
    {
        int playerChoice = user.menu();
        while(playerChoice != 3)
        {
            if(playerChoice == 1)
            {
                user.getPlayerBet();
                userHand.newHand();
                user.showHand(userHand.getHand());
                //Code above sets up the player's hand and amount they are betting
                
                int[] userDiscards = user.getDiscards();
                for(int i = 0; i < userDiscards.length; i++)
                {
                    userHand.discard(userDiscards[i]); //replaces discarded cards with new ones
                }
                
                user.showHand(userHand.getHand());
                
                user.updateBankroll((user.displayResults(userHand.scoreHand()))*(userHand.scoreHand()));
                playerChoice = user.menu();
            } 
            else if(playerChoice == 2)
            {
                user.updateBankroll(user.addToBankroll());
                playerChoice = user.menu();
            }
        }
        user.quit();
    }
}