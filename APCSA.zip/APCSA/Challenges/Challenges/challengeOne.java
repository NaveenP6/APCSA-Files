public class challengeOne
{

    public static void main(String args[])
    {
        one();
    }
    public static int one()
    {
        int perfectNumbersSum = 0;
        for (int i = 1; i < 1000; i++)
        {
            int sum = 0;
            for (int j = 1; j <= i/2; j++)
            {
                if (i % j == 0)
                {
                    sum += j;
                }
            }
            if (i == sum)
            {
                perfectNumbersSum += sum;
            }
        }
        return perfectNumbersSum;
    }

}