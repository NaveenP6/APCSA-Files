public class challengeNine
{
    
    public static void main (String[] args)
    {
        challengeNine();
    }
    
    public static int factorial(int a)
    {
        int num1 = 1;
        for(int i = 1; i <= a; i++)
        {
            num1 *= i;
        }
        return num1;
    }
    public static int challengeNine()
    {
       int curiousNumberSum = 0;
       int finalCuriousNumberSum = 0;
       for (int i = 3; i < 100000; i++)
       {
           int j = i;
           while (j > 0)
           {
               curiousNumberSum += factorial(j % 10);
               j/=10;
           }
           if (curiousNumberSum == i)
           {
               finalCuriousNumberSum += i;
           }
           curiousNumberSum = 0;
       }
       return finalCuriousNumberSum;
    }
}