import java.math.BigInteger;
public class challengeSeven
{
    public static void main (String[] args)
    {
        seven();
    }
    public static int seven()
    {
        BigInteger num1 = new BigInteger("100");
        BigInteger sum = new BigInteger("0");
        
        for(BigInteger i = new BigInteger("1"); i.compareTo(new BigInteger("100")) <= 0; i = i.add(new BigInteger("1")))
        {
            num1 = num1.multiply(i);
        }
        
        while(num1.compareTo(new BigInteger("0")) > 0)
        {
            sum = sum.add(num1.mod(new BigInteger("10")));
            num1 = num1.divide(new BigInteger("10"));
        }
        
        return sum.intValue();
    }
}