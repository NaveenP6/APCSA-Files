public class challengeFive
{
    public static void main (String[] args)
    {
        challengeFive();
    }
    public static String reverseString(String a)
    {
      String b = "";
      for (int i = a.length()-1; i>=0; i--)
      {
       b += a.substring(i,i+1);
      }
      return b;
    }
    public static boolean challengeFiveTester(String a)
    {
       String b = reverseString(a);
       if (a.equals(b))
       {
           return true;
       }
       else
       {
           return false;
       }
    }
    public static int challengeFive()
    {
       int test = 0;
       int maxPalindrome = 0;
       for (int i = 999; i >= 100; i--)
       {
           for (int j = 999; j >= 100; j--)
           {
               test = i * j; 
               String a = test + "";
               if (challengeFiveTester(a) && test > maxPalindrome)
               {
                   maxPalindrome = test;
               }
           }
       }
       return maxPalindrome;
    }
}