
public class challengeThree
{
    public static void main (String[] args)
    {
        three();
    }
    
    public static int three()
    {
        int sum = 0;
        for(int i = 1; i < 1000; i++)
        {
            if(i % 3 == 0 || i % 5 == 0)
            {
                sum += i;
            }
        }
        return sum;
    }

}