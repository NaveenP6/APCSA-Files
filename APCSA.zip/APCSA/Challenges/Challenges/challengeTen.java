public class challengeTen
{
    public static void main (String[] args)
    {
        ten();
    }
    
    public static int ten()     
    {         
        int product = 0;         
        for (int a = 1; a < 1000; a++)          
        {             
            for (int b = a+1; b < 1000; b++)              
            {                 
                int c = 1000 - a - b;                  
                if(c > b && a*a + b*b == c*c)                 
                {                     
                    product = a * b * c;                     
                    // System.out.println("a=" + a + ", b=" + b + ", c=" + c);                     
                    // product = ("Product abc = " + product);                                      
                }             
            }         
        }         
        return product;     
    }
}