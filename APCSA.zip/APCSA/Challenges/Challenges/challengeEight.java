public class challengeEight
{
    public static void main (String[] args)
    {
        challengeEightExecutor();
    }
    public static boolean challengeEightIsPrime(long num)
    {
        if (num == 1)
        {
            return false;
        }
        else if (num == 2 || num == 3)
        {
            return true;
        }
        else if (num % 2 == 0)
        {
            return false;
        }
        
        for (long i = 3; i <= Math.sqrt(num); i+=2)
        {
            
            if (num % i == 0)
            {
                return false;
            }
        }
    
        return true;
    }
    public static int challengeEightRotater (int num, int sLength)
    {
        int tempMod = num % 10;
        int tempDivide = num/10;
        int answer = (int)(tempMod * Math.pow(10, sLength-1)) + tempDivide;
        return answer;
    }
    public static int challengeEightExecutor()
    {
        //create variable to track circular primes
        //if thing is prime 
        //last digit to end check prime for length of number times
        //return variable
        
        int circularPrimeNumberCount = 0;
        for (int i = 0; i < 1000000; i++)
        {
            int rotatorCounter = 0;
            int temp = i;
            String s = i + "";
            for (int j = 0; j < s.length(); j++)
            {
                if (challengeEightIsPrime(temp) == true)
                {
                    rotatorCounter++;
                    temp = challengeEightRotater(temp, s.length());
                }
            }
            if (rotatorCounter == s.length())
            {
                circularPrimeNumberCount++;
            }
        }
        return circularPrimeNumberCount;
    }
}
