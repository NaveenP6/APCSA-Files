public class challengeFour
{
    public static void main (String[] args)
    {
        four();
    }
    public static boolean isPrime(long num)
    { 

          if (num == 1)
          {
             return false;
          }
          else if (num == 2 || num == 3)
          {
             return true;
          }
          else if (num % 2 == 0)
          {
             return false;
          }
         
          for (long i = 3; i <= Math.sqrt(num);  i+=2)
          {
             if (num % i == 0)
             {
                return false;
             }
          }
          return true;
    }
    
    public static long four()
    {
        long primeFactor = 0;
        for(long i = 1; i < (long)Math.sqrt(600851475143L); i++)
        {
            if(isPrime(i) == true && 600851475143L% i == 0)
            {
                primeFactor = i;     
            }
        }
        return primeFactor;

    }
   
   
   
}