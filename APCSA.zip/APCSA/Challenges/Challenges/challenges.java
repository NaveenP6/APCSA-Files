import java.math.BigInteger;

public class challenges
{
    
    public static void main (String[] args)
    {
        challengeSix();
    }
    
    
    // An orderly number is one where the n-leftmost numbers are 
    // divisible by n. An example would be 12325, where 1 is divisible 
    // by 1, 12 is divisible by 2, 123 is divisible by 3, 1232 is 
    // divisible by 4, and 12325 is divisible by 5. There is only 
    // one 10 digit orderly number that has exactly each digit 0-9 once. 
    // What is it?
    public static int challengeTwo()
    {
        return 100;
    }
    
    
    
    //COMPLETE
    public static int challengeThree()
    {
        int sum = 0;
        for(int i = 1; i < 1000; i++)
        {
            if(i % 3 == 0 || i % 5 == 0)
            {
                sum += i;
            }
        }
        return sum;
    }
    
    //COMPLETE
    // What is the smallest number that is evenly 
    // divisible by all numbers from 1 to 20?
    public static int challengeSix()
    {
        boolean divisible = false;
        int i = 1;
        while(divisible == false)
        {
            if(i % 1 == 0 && i % 2 == 0 && i % 3 == 0 && i % 4 == 0 && i % 5 == 0 && i % 6 == 0 && i % 7 == 0 && i % 8 == 0 && i % 9 == 0 && i % 10 == 0 && i % 11 == 0 && i % 12 == 0 && i % 13 == 0 && i % 14 == 0 && i % 15 == 0 && i % 16 == 0 && i % 17 == 0 && i % 18 == 0 && i % 19 == 0 && i % 20 == 0)
            {
                divisible = true;
            }
            
            if(divisible == false)
            {
                i++;
            }
        }
        return i;
    }

    //COMPLETE
    // n! (factorial) means n× (n − 1) × ... × 3 × 2 × 1. 
    // For example, 10! = 10 × 9 × ... × 3 × 2 × 1 = 3628800, 
    // and the sum of the digits in the number 10! is 
    // 3 + 6 + 2 + 8 + 8 + 0 + 0 = 27. 
    // Find the sum of the digits in the number 100!
    public static int challengeSeven()
    {
        BigInteger num1 = new BigInteger("100");
        BigInteger sum = new BigInteger("0");
        for(BigInteger i = new BigInteger("1"); i.compareTo(new BigInteger("100")) <= 0; i = i.add(new BigInteger("1")))
        {
            num1 = num1.multiply(i);
        }
        
        while(num1.compareTo(new BigInteger("0")) > 0)
        {
            sum = sum.add(num1.mod(new BigInteger("10")));
            num1 = num1.divide(new BigInteger("10"));
        }
        
        return sum.intValue();
    }
    
    public static int challengeTen()     
    {         
        int product = 0;         
        for (int a = 1; a < 1000; a++)          
        {             
            for (int b = a + 1; b < 1000; b++)              
            {                 
                int c = 1000 - a - b;                  
                if(c > b && a*a + b*b == c*c)                 
                {                     
                    product = a * b * c;                     
                    // System.out.println("a=" + a + ", b=" + b + ", c=" + c);                     
                    // product = ("Product abc = " + product);                                      
                }             
            }         
        }         
        return product;     
    }
}